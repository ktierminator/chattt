# Deployment Guide - ChatKool

This guide will help you deploy your chatroom application to the internet so anyone can access it.

## 🚀 Quick Deploy Options

### Option 1: Vercel (Recommended - Easiest)

1. **Sign up for Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Sign up with GitHub, GitLab, or Bitbucket

2. **Install Vercel CLI** (Optional)
   ```bash
   npm install -g vercel
   ```

3. **Deploy**
   ```bash
   # From your project directory
   vercel
   ```

4. **Follow the prompts**
   - Select your project
   - Choose settings (defaults are fine)
   - Wait for deployment

5. **Done!** 
   - You'll get a URL like: `https://chatkool-abc123.vercel.app`
   - Share this URL with anyone!

**Advantages:**
- ✅ Free tier available
- ✅ Automatic HTTPS
- ✅ Global CDN
- ✅ Instant deployments
- ✅ Auto-deploy on git push

### Option 2: Netlify

1. **Sign up for Netlify**
   - Go to [netlify.com](https://netlify.com)
   - Sign up with GitHub, GitLab, or Bitbucket

2. **Deploy via Drag & Drop**
   - Build your project: `npm run build`
   - Go to Netlify dashboard
   - Drag the `dist` folder to the deploy area

3. **Or Deploy via CLI**
   ```bash
   npm install -g netlify-cli
   npm run build
   netlify deploy --prod --dir=dist
   ```

4. **Done!**
   - You'll get a URL like: `https://chatkool.netlify.app`

**Advantages:**
- ✅ Free tier available
- ✅ Simple drag-and-drop
- ✅ Forms and functions support
- ✅ Easy custom domains

### Option 3: GitHub Pages

1. **Create GitHub Repository**
   - Create a new repo on GitHub
   - Push your code

2. **Install gh-pages**
   ```bash
   npm install --save-dev gh-pages
   ```

3. **Update package.json**
   ```json
   {
     "homepage": "https://yourusername.github.io/chatkool",
     "scripts": {
       "predeploy": "npm run build",
       "deploy": "gh-pages -d dist"
     }
   }
   ```

4. **Deploy**
   ```bash
   npm run deploy
   ```

5. **Enable GitHub Pages**
   - Go to repo Settings > Pages
   - Select `gh-pages` branch
   - Save

**Advantages:**
- ✅ Free for public repos
- ✅ Integrated with GitHub
- ✅ Simple workflow

### Option 4: Firebase Hosting

Since you're already using Firebase for the database:

1. **Install Firebase CLI**
   ```bash
   npm install -g firebase-tools
   ```

2. **Login to Firebase**
   ```bash
   firebase login
   ```

3. **Initialize Firebase Hosting**
   ```bash
   firebase init hosting
   ```
   - Select your Firebase project
   - Set `dist` as public directory
   - Configure as single-page app: Yes
   - Don't overwrite index.html

4. **Build and Deploy**
   ```bash
   npm run build
   firebase deploy --only hosting
   ```

**Advantages:**
- ✅ Same platform as your database
- ✅ Free tier available
- ✅ Fast global CDN
- ✅ Easy rollbacks

### Option 5: Cloudflare Pages

1. **Sign up for Cloudflare**
   - Go to [pages.cloudflare.com](https://pages.cloudflare.com)

2. **Connect Repository**
   - Connect your GitHub/GitLab repo
   - Or upload directly

3. **Configure Build**
   - Build command: `npm run build`
   - Output directory: `dist`

4. **Deploy**
   - Cloudflare will build and deploy automatically

**Advantages:**
- ✅ Free unlimited bandwidth
- ✅ Global CDN
- ✅ DDoS protection
- ✅ Analytics included

## 🔧 Pre-Deployment Checklist

Before deploying, make sure:

- [ ] Project builds successfully: `npm run build`
- [ ] All environment variables are set (if using custom Firebase)
- [ ] Firebase Realtime Database rules are configured
- [ ] All features work in production build
- [ ] Mobile responsive design is tested
- [ ] All images/assets are optimized

## 🌐 Custom Domain Setup

### For Vercel:
1. Go to Project Settings > Domains
2. Add your custom domain
3. Update DNS records as instructed
4. SSL certificate auto-generated

### For Netlify:
1. Go to Domain Settings
2. Add custom domain
3. Update DNS records
4. SSL certificate auto-generated

### For Firebase Hosting:
1. `firebase hosting:channel:deploy production`
2. Add custom domain in Firebase Console
3. Update DNS records
4. SSL certificate auto-generated

## 🔒 Firebase Security Rules

If using Firebase, update your Realtime Database rules:

### Development (Open - Not Recommended for Production)
```json
{
  "rules": {
    ".read": true,
    ".write": true
  }
}
```

### Production (Recommended)
```json
{
  "rules": {
    "rooms": {
      "$roomId": {
        ".read": true,
        ".write": true,
        "messages": {
          ".indexOn": ["timestamp"]
        },
        "users": {
          "$userId": {
            ".validate": "newData.hasChildren(['id', 'name', 'lastSeen'])"
          }
        }
      }
    }
  }
}
```

## 📊 Post-Deployment

### Test Your Deployment

1. **Open the deployed URL**
2. **Test on multiple devices**
   - Desktop browser
   - Mobile browser
   - Tablet
3. **Test core features**
   - Create room
   - Join room
   - Send messages
   - Upload files
   - Share link
4. **Test with friends**
   - Share link with 2-3 people
   - Have a real conversation
   - Check for any issues

### Monitor Usage

#### Vercel Analytics
- Free analytics included
- View traffic, performance, etc.

#### Netlify Analytics
- Paid feature
- Detailed visitor insights

#### Firebase Analytics
```bash
# Add to your Firebase project
npm install firebase/analytics
```

#### Google Analytics
```html
<!-- Add to index.html -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
```

## 🔄 Continuous Deployment

### Auto-Deploy on Git Push

Most platforms support this:

1. **Connect your Git repository**
2. **Every push to main branch triggers deploy**
3. **Preview deployments for pull requests**

Example workflow:
```
git add .
git commit -m "Update feature"
git push origin main
# Automatically deploys!
```

## 💰 Cost Considerations

### Free Tier Limits

**Vercel:**
- ✅ 100 GB bandwidth/month
- ✅ Unlimited projects
- ✅ Automatic HTTPS

**Netlify:**
- ✅ 100 GB bandwidth/month
- ✅ 300 build minutes/month
- ✅ Automatic HTTPS

**Firebase:**
- ✅ 10 GB storage
- ✅ 360 MB/day downloads
- ✅ 100 connections (Realtime Database)

**GitHub Pages:**
- ✅ 100 GB bandwidth/month
- ✅ Public repos only

**Cloudflare Pages:**
- ✅ Unlimited bandwidth
- ✅ 500 builds/month

### Scaling Considerations

If your app gets popular:

1. **Upgrade Firebase Plan** ($25/month Blaze plan)
2. **Consider Pro Plans** for hosting ($20-40/month)
3. **Implement Rate Limiting** to prevent abuse
4. **Add Caching** for better performance
5. **Monitor Costs** regularly

## 🐛 Troubleshooting

### Build Fails
```bash
# Clear cache and rebuild
rm -rf node_modules dist
npm install
npm run build
```

### Environment Variables Not Working
- Make sure they start with `VITE_`
- Rebuild after adding env vars
- Check platform-specific env var setup

### Firebase Connection Issues
- Check Firebase config in `src/lib/firebase.ts`
- Verify API keys are correct
- Check Firebase Database rules
- Ensure Realtime Database is enabled

### 404 Errors on Reload
- Configure as Single Page App (SPA)
- Add redirect rules for hosting platform

## 📱 Share Your App

Once deployed, share your chatroom:

1. **Social Media**
   - Post on Twitter, Facebook, etc.
   - Use hashtags: #chatroom #webapp #opensource

2. **Product Hunt**
   - Submit as a product
   - Great for feedback and users

3. **Reddit**
   - r/webdev
   - r/InternetIsBeautiful
   - r/SideProject

4. **Friends & Family**
   - Test with real users
   - Get feedback
   - Improve based on usage

## 🎉 You're Live!

Congratulations! Your chatroom is now accessible to anyone in the world!

**Share your deployment URL and let people chat! 🚀**

---

Need help? Check the platform-specific documentation:
- [Vercel Docs](https://vercel.com/docs)
- [Netlify Docs](https://docs.netlify.com)
- [Firebase Docs](https://firebase.google.com/docs/hosting)
- [GitHub Pages Docs](https://docs.github.com/en/pages)
- [Cloudflare Pages Docs](https://developers.cloudflare.com/pages)
