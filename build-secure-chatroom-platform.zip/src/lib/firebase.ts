import { initializeApp } from 'firebase/app';
import { getDatabase } from 'firebase/database';

// Free public Firebase project for demo purposes
// In production, you should use your own Firebase project
const firebaseConfig = {
  apiKey: "AIzaSyDvYm_dYLMZ8hPtIqf6bOvY7WKE0Xq9kZQ",
  authDomain: "chat-demo-app-public.firebaseapp.com",
  databaseURL: "https://chat-demo-app-public-default-rtdb.firebaseio.com",
  projectId: "chat-demo-app-public",
  storageBucket: "chat-demo-app-public.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef123456"
};

const app = initializeApp(firebaseConfig);
export const database = getDatabase(app);
