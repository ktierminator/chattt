# 🚀 Quick Start Guide - ChatKool

Get your chatroom up and running in 2 minutes!

## ⚡ Super Quick Start

### For Users (No Setup Required)

1. **Open the app** (if deployed) or run locally
2. **Enter your name** (e.g., "Alice")
3. **Click "New Code"** to generate a room code
4. **Click "Join Room"**
5. **Copy the link** using the "Copy Join Link" button
6. **Share with friends** via WhatsApp, Email, SMS, etc.
7. **Start chatting!** 🎉

That's it! Your friends just click the link and they're in!

## 💻 For Developers

### Local Development

```bash
# 1. Install dependencies
npm install

# 2. Start development server
npm run dev

# 3. Open in browser
# Usually: http://localhost:5173
```

### Build for Production

```bash
# Build the project
npm run build

# The output will be in the 'dist' folder
```

### Deploy to Vercel (Easiest)

```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel

# Follow the prompts and you're done!
```

## 🎯 Key Features at a Glance

| Feature | Description |
|---------|-------------|
| 🌍 **Global Access** | Works from any device, anywhere |
| 💬 **Real-Time** | Messages appear instantly |
| 📸 **Media Sharing** | Send images and videos |
| 🔗 **Easy Sharing** | Just share a link |
| 🔒 **No Sign-Up** | Anonymous, no registration |
| 📱 **Mobile-First** | Works on phones, tablets, PCs |

## 🔗 How Link Sharing Works

When you create a room, you get:
1. **Room Code**: 6 characters (e.g., `ABC123`)
2. **Shareable Link**: `https://yoursite.com/?room=ABC123`

Share either one, and people can join!

## 📱 Supported Devices

- ✅ iPhone & Android phones
- ✅ Tablets (iPad, etc.)
- ✅ Laptops (Windows, Mac, Linux)
- ✅ Desktop computers
- ✅ Any modern web browser

## 🌐 Cross-Device Example

**Scenario:** You're on your laptop, friend is on their phone.

1. **You (Laptop):**
   - Create room "MEETING"
   - Copy link: `https://chatroom.com/?room=MEETING`
   - Send to friend via WhatsApp

2. **Friend (Phone):**
   - Clicks the link
   - Opens in phone browser
   - Enters name and joins
   - Starts chatting!

3. **Result:**
   - Both of you are in the same room
   - Messages sync instantly
   - Can share photos/videos
   - Works even if you're in different countries!

## 🎨 UI Overview

```
┌─────────────────────────────────────────────┐
│  SIDEBAR           │  CHAT AREA             │
│  ┌────────────┐   │  ┌──────────────────┐  │
│  │ Room: ABC  │   │  │  Messages        │  │
│  │ Copy Link  │   │  │  [User]: Hi!     │  │
│  │            │   │  │  [You]: Hello!   │  │
│  │ Users (2)  │   │  │                  │  │
│  │ • Alice    │   │  └──────────────────┘  │
│  │ • Bob      │   │  [Type message...]      │
│  └────────────┘   │  [📎] [Send]            │
└─────────────────────────────────────────────┘
```

## 🧪 Testing Multi-Device

**Easy Test:**
1. Open the app on your computer
2. Create a room
3. Open the same link on your phone
4. Enter a different name
5. Send messages from both devices
6. Watch them appear instantly!

## 🔥 Use Cases

### 1. Quick Team Meeting
```
Manager: Creates room "STANDUP"
Team: Joins via link
Result: Quick discussion without Zoom fatigue
```

### 2. Share Photos with Family
```
You: Create room "VACATION"
Family: Joins from their phones
Result: Everyone uploads and views photos
```

### 3. Study Group
```
Student 1: Creates room "MATH101"
Other students: Join via shared link
Result: Discuss homework, share notes
```

### 4. Tech Support
```
Helper: Creates room "SUPPORT"
User: Joins and shares screenshots
Result: Visual troubleshooting
```

## 📊 Tech Stack

- **Frontend:** React + TypeScript + Vite
- **Styling:** Tailwind CSS
- **Database:** Firebase Realtime Database
- **Icons:** Lucide React
- **Notifications:** React Hot Toast
- **Routing:** React Router

## 🛠️ Configuration

### Default Configuration
Works out of the box with demo Firebase project!

### Custom Configuration (Optional)
For production use, set up your own Firebase:

1. Create Firebase project at [console.firebase.google.com](https://console.firebase.google.com)
2. Enable Realtime Database
3. Copy config to `src/lib/firebase.ts`
4. Rebuild and deploy

## 🎓 Learning Resources

- **React:** [react.dev](https://react.dev)
- **Vite:** [vitejs.dev](https://vitejs.dev)
- **Tailwind:** [tailwindcss.com](https://tailwindcss.com)
- **Firebase:** [firebase.google.com/docs](https://firebase.google.com/docs)

## 📞 Support

Having issues? Check these files:
- **Full Features:** See `FEATURES.md`
- **Testing Guide:** See `TESTING.md`
- **Deployment:** See `DEPLOYMENT.md`
- **Main README:** See `README.md`

## 🎉 Success Stories

**What People Can Do:**

✅ Video call team while sharing code snippets
✅ Plan events with real-time photo sharing
✅ Remote gaming with instant coordination
✅ Family reunions with multi-device access
✅ International friendships with no barriers
✅ Quick customer support sessions
✅ Anonymous brainstorming sessions
✅ Collaborative note-taking

## 🚀 Next Steps

1. **Test it locally** - Run `npm run dev`
2. **Test cross-device** - Open on phone and PC
3. **Share with friends** - Get real feedback
4. **Deploy it** - Use Vercel for free hosting
5. **Customize it** - Make it your own!

## ⭐ Pro Tips

- 💡 **Tip 1:** Room codes are case-insensitive
- 💡 **Tip 2:** Press Shift+Enter for new lines
- 💡 **Tip 3:** Files under 5MB work best
- 💡 **Tip 4:** Works on any WiFi or mobile data
- 💡 **Tip 5:** No app installation needed!

---

**Ready? Let's go! 🚀**

Start with: `npm install && npm run dev`

Then open your browser and create your first room!
