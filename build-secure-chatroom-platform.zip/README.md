# ChatKool - Real-Time Chatroom Application

A modern, real-time chatroom application inspired by Omegle and ChatKool. Connect with anyone across the globe using just a room code or shareable link!

## ✨ Features

### 🔗 Easy Access
- **Room Codes**: Create or join rooms using simple 6-character codes
- **Shareable Links**: Copy and share room links instantly
- **Cross-Device Support**: Works seamlessly across phones, tablets, laptops, and desktops
- **Global Access**: Anyone with the link or code can join from anywhere in the world

### 💬 Rich Messaging
- **Real-Time Text Chat**: Messages appear instantly for all connected users
- **Image Sharing**: Upload and share images (up to 5MB)
- **Video Sharing**: Upload and share videos (up to 5MB)
- **File Preview**: Images and videos display inline in the chat

### 👥 User Management
- **Live User List**: See who's currently in the room
- **Join/Leave Notifications**: Get notified when users join or leave
- **User Presence**: Real-time tracking of active users
- **Display Names**: Personalized chat experience with custom usernames

### 🎨 Modern UI/UX
- **Dark Mode**: Easy on the eyes with a sleek dark theme
- **Responsive Design**: Optimized for mobile and desktop
- **Smooth Animations**: Polished transitions and effects
- **Message Bubbles**: Distinct styles for your messages vs others
- **Timestamp Display**: See when each message was sent

## 🚀 How It Works

### Technology Stack
- **Frontend**: React + TypeScript + Vite
- **Styling**: Tailwind CSS
- **Real-Time Database**: Firebase Realtime Database
- **Notifications**: React Hot Toast
- **Icons**: Lucide React

### Architecture
1. **Firebase Backend**: Messages and user presence are synced through Firebase Realtime Database
2. **Real-Time Sync**: All users in a room receive updates instantly
3. **No Authentication Required**: Simple, anonymous chat experience
4. **Automatic Cleanup**: User presence automatically updated

## 📖 Usage

### Creating a Room
1. Enter your display name
2. Click "Create New Room"
3. Share the generated room code or link with others

### Joining a Room
1. Enter your display name
2. Enter the room code OR use a shared link
3. Click "Join Room"
4. Start chatting!

### Sending Messages
- Type your message and press Enter (or click Send)
- Use Shift+Enter for new lines
- Click the paperclip icon to attach images or videos

## 🔒 Privacy & Security
- No data is permanently stored - messages exist only while the room is active
- No user registration or authentication required
- Anonymous chatting experience
- Files are transmitted as base64 data

## ⚙️ Setup (Optional - For Production)

The app comes pre-configured with a demo Firebase project. For production use, set up your own:

1. **Create a Firebase Project**
   - Go to [Firebase Console](https://console.firebase.google.com/)
   - Create a new project
   - Enable Realtime Database (Start in test mode)

2. **Get Configuration**
   - Go to Project Settings > General
   - Scroll to "Your apps" and add a Web app
   - Copy the configuration values

3. **Update Configuration**
   - Rename `.env.example` to `.env`
   - Fill in your Firebase configuration values
   - Update `src/lib/firebase.ts` to use environment variables

4. **Build and Deploy**
   ```bash
   npm install
   npm run build
   ```

## 🌐 Deployment
The application is built as a static site and can be deployed to:
- Vercel
- Netlify
- GitHub Pages
- Any static hosting service

## 📱 Browser Support
- Chrome (recommended)
- Firefox
- Safari
- Edge
- Mobile browsers (iOS Safari, Chrome Mobile)

## 🎯 Perfect For
- Quick team chats
- Temporary group discussions
- Sharing media with friends
- Anonymous conversations
- Remote collaboration

---

Built with ❤️ using React, Vite, Tailwind CSS, and Firebase
