# Testing Guide - ChatKool

This guide will help you test the chatroom functionality across multiple devices and verify that anyone can connect using the link or code.

## 🧪 Basic Testing (Single Device)

### Test 1: Create and Join a Room
1. Open the app in your browser
2. Enter a display name (e.g., "Alice")
3. Click "New Code" to generate a room code
4. Click "Join Room"
5. You should see the chat interface with your name in the user list

### Test 2: Send Messages
1. Type a message in the input field
2. Press Enter or click Send
3. The message should appear in the chat with your name and timestamp
4. Try sending multiple messages

### Test 3: Share Media
1. Click the paperclip icon
2. Select an image or video (under 5MB)
3. The file should upload and appear in the chat
4. Images should display inline
5. Videos should have playback controls

## 🌐 Cross-Device Testing

### Test 4: Multiple Tabs (Same Device)
1. **Tab 1**: Create a room with name "Alice"
2. Copy the room link using "Copy Join Link" button
3. **Tab 2**: Open a new tab/window
4. Paste the link and enter name "Bob"
5. Click "Join Room"
6. **Expected Result**:
   - Bob should see Alice in the user list
   - Alice should see Bob join notification
   - Both should see 2 users connected
7. Send messages from both tabs
8. **Expected Result**: Messages appear in both tabs instantly

### Test 5: Different Devices (Same Network)
1. **Device 1** (e.g., laptop): Create a room with name "Alice"
2. Copy the room link
3. **Device 2** (e.g., phone): Open the link
4. Enter a different name (e.g., "Bob")
5. Join the room
6. **Expected Result**:
   - Both devices show 2 users connected
   - Messages sent from one device appear on the other
   - Both can send and receive media files

### Test 6: Different Devices, Different Networks
This is the ultimate test to verify global accessibility!

1. **Device 1** (WiFi): Create a room with name "Alice"
2. Copy the room link or note the room code
3. **Device 2** (Mobile data/Different WiFi): 
   - Open the app
   - Either paste the link OR manually enter the room code
   - Use a different name (e.g., "Bob")
   - Join the room
4. **Expected Result**:
   - Both devices connect successfully
   - Real-time messaging works
   - Files can be shared between devices
   - User list updates on both sides

### Test 7: Share Link via Messaging Apps
1. Create a room on your device
2. Copy the join link
3. Send the link via:
   - WhatsApp
   - SMS/Text
   - Email
   - Telegram
   - Discord
   - Any other messaging app
4. Open the link on another device
5. **Expected Result**: Should join the room successfully

## 📱 Device-Specific Testing

### Test 8: Mobile Browser (iOS Safari)
1. Open the link on iPhone/iPad
2. Enter your name and join
3. Test portrait and landscape modes
4. Test keyboard behavior
5. Test file upload from camera/gallery

### Test 9: Mobile Browser (Android Chrome)
1. Open the link on Android device
2. Enter your name and join
3. Test portrait and landscape modes
4. Test file upload from camera/gallery
5. Test notification permissions

### Test 10: Desktop Browsers
Test on multiple browsers:
- Chrome
- Firefox
- Safari (Mac)
- Edge

**Expected Result**: Should work identically on all browsers

## 🔗 Link Sharing Methods

### Method 1: Copy Link Button
1. Use "Copy Join Link" in the chat interface
2. Share via any app
3. Recipient clicks link
4. Should auto-fill room code

### Method 2: Manual Room Code
1. Share just the 6-character code
2. Recipient manually enters code
3. Should join the same room

### Method 3: URL with Room Parameter
1. Share URL like: `https://yoursite.com/?room=ABC123`
2. Recipient opens link
3. Room code should be pre-filled
4. Just need to enter name and join

## 👥 Multi-User Testing

### Test 11: Group Chat (3+ Users)
1. Create a room on Device 1
2. Share link to 2+ other devices
3. All devices join with different names
4. **Expected Result**:
   - All users appear in user list
   - Messages from any user appear for all
   - Join/leave notifications work for all
   - Real-time sync across all devices

### Test 12: User Leave/Rejoin
1. User 1 and User 2 in a room
2. User 2 leaves (close tab or click Leave)
3. **Expected**: User 1 sees leave notification
4. User 2 rejoins with same link
5. **Expected**: User 1 sees join notification

## 🌍 Geographic Testing

### Test 13: International Connection
If possible, test with users in different countries:
1. User in Country A creates room
2. User in Country B joins via link
3. **Expected Result**: Should work seamlessly

### Test 14: Network Switching
1. Join a room on WiFi
2. Switch to mobile data (without refreshing)
3. Continue chatting
4. **Expected Result**: Should auto-reconnect

## ⚡ Performance Testing

### Test 15: Message Flood
1. Send 20-30 messages rapidly
2. **Expected Result**:
   - All messages appear
   - No lag or freeze
   - Correct order maintained
   - Auto-scroll works

### Test 16: Large File Upload
1. Upload a 4-5MB image
2. **Expected Result**:
   - Upload succeeds
   - Image displays correctly
   - Received by other users

### Test 17: Multiple Files
1. Upload several images in succession
2. **Expected Result**:
   - All upload successfully
   - Display in correct order
   - Other users receive all files

## 🐛 Error Handling Testing

### Test 18: Oversized File
1. Try to upload file > 5MB
2. **Expected Result**: Error message displayed

### Test 19: Invalid Room Code
1. Try to join with gibberish code
2. Should still create/join that room

### Test 20: Connection Loss
1. Join a room
2. Disconnect internet
3. Reconnect internet
4. **Expected Result**: Should auto-reconnect

## ✅ Success Criteria

Your chatroom is working correctly if:

- ✅ Users on different devices can connect
- ✅ Users on different networks can connect
- ✅ Messages appear instantly for all users
- ✅ Images and videos can be shared
- ✅ User list updates in real-time
- ✅ Notifications work correctly
- ✅ Mobile and desktop both work
- ✅ Link sharing works via any method
- ✅ Multiple users can chat simultaneously
- ✅ Connection is stable and fast

## 📸 Testing Checklist

Before deploying, verify:

- [ ] Create room works
- [ ] Join room works
- [ ] Manual code entry works
- [ ] Link sharing works
- [ ] Copy link button works
- [ ] Text messages send/receive
- [ ] Images upload and display
- [ ] Videos upload and play
- [ ] User list updates
- [ ] Join notifications appear
- [ ] Leave notifications appear
- [ ] Mobile responsive design works
- [ ] Desktop layout works
- [ ] Multiple browsers work
- [ ] Different devices connect
- [ ] Different networks connect
- [ ] International access works

## 🎉 Real-World Usage

To truly test the app:

1. **Share with Friends**: Send the link to 2-3 friends
2. **Have a Conversation**: Chat naturally for 5-10 minutes
3. **Share Media**: Exchange some photos or videos
4. **Observe Behavior**: Note any issues or lag
5. **Gather Feedback**: Ask for their experience

---

**Happy Testing! 🚀**

If you find any issues, check the browser console for error messages.
