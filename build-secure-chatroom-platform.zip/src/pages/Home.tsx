import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { MessagesSquare } from 'lucide-react';

export default function Home() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  
  const [displayName, setDisplayName] = useState(localStorage.getItem('chatkool_name') || '');
  const [roomCode, setRoomCode] = useState(searchParams.get('room') || '');

  const handleJoin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!displayName.trim() || !roomCode.trim()) return;
    
    localStorage.setItem('chatkool_name', displayName.trim());
    navigate(`/room/${roomCode.trim()}`);
  };

  const generateCode = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setRoomCode(code);
  };

  return (
    <div className="min-h-screen bg-neutral-950 flex flex-col items-center justify-center p-4 text-white">
      <div className="w-full max-w-md bg-neutral-900 rounded-2xl p-8 shadow-xl border border-neutral-800">
        <div className="flex flex-col items-center mb-8">
          <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mb-4">
            <MessagesSquare size={32} />
          </div>
          <h1 className="text-3xl font-bold tracking-tight">ChatKool</h1>
          <p className="text-neutral-400 mt-2 text-center">Connect with anyone, anywhere in real-time.</p>
        </div>

        <form onSubmit={handleJoin} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-neutral-300 mb-1">Display Name</label>
            <input
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="What should we call you?"
              className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-4 py-3 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
              required
              maxLength={20}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-neutral-300 mb-1">Room Code</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={roomCode}
                onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
                placeholder="Enter room code"
                className="flex-1 bg-neutral-950 border border-neutral-800 rounded-lg px-4 py-3 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors uppercase font-mono"
                required
                maxLength={20}
              />
              <button
                type="button"
                onClick={generateCode}
                className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-lg transition-colors font-medium text-sm whitespace-nowrap"
              >
                New Code
              </button>
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-3 font-semibold transition-colors mt-6"
          >
            Join Room
          </button>
        </form>

        <div className="mt-6 pt-6 border-t border-neutral-800">
          <div className="text-sm text-neutral-400 space-y-2">
            <p className="font-semibold text-neutral-300 mb-3">✨ Features:</p>
            <ul className="space-y-1.5 text-xs">
              <li>🌍 Works across all devices and networks</li>
              <li>💬 Real-time text messaging</li>
              <li>📸 Share images and videos (up to 5MB)</li>
              <li>🔗 Share room link to invite others</li>
              <li>🔒 No registration required</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}