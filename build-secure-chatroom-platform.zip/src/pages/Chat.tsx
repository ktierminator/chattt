import { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { v4 as uuidv4 } from 'uuid';
import toast from 'react-hot-toast';
import { Share2, Paperclip, Send, Users, LogOut } from 'lucide-react';
import { cn } from '../utils/cn';
import { database } from '../lib/firebase';
import { ref, push, onChildAdded, onValue, set, remove, serverTimestamp } from 'firebase/database';

interface ChatMessage {
  id: string;
  sender: string;
  senderId: string;
  text?: string;
  fileData?: string;
  fileType?: string;
  fileName?: string;
  timestamp: number;
}

interface User {
  id: string;
  name: string;
  lastSeen: number;
}

export default function Chat() {
  const { roomId } = useParams<{ roomId: string }>();
  const navigate = useNavigate();
  const displayName = localStorage.getItem('chatkool_name');

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [users, setUsers] = useState<User[]>([]);
  const [isConnecting, setIsConnecting] = useState(true);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const myId = useRef<string>(uuidv4());
  const userPresenceRef = useRef<any>(null);

  useEffect(() => {
    if (!displayName) {
      navigate(`/?room=${roomId}`);
      return;
    }

    if (!roomId) return;

    // Setup presence
    const myUserRef = ref(database, `rooms/${roomId}/users/${myId.current}`);
    userPresenceRef.current = myUserRef;

    set(myUserRef, {
      id: myId.current,
      name: displayName,
      lastSeen: serverTimestamp()
    });

    // Update presence every 3 seconds
    const presenceInterval = setInterval(() => {
      set(myUserRef, {
        id: myId.current,
        name: displayName,
        lastSeen: serverTimestamp()
      });
    }, 3000);

    // Listen for users
    const usersRef = ref(database, `rooms/${roomId}/users`);
    const unsubscribeUsers = onValue(usersRef, (snapshot) => {
      const usersData: User[] = [];
      const now = Date.now();
      
      snapshot.forEach((childSnapshot) => {
        const user = childSnapshot.val() as User;
        // Only show users who were active in the last 10 seconds
        if (user && (!user.lastSeen || (now - user.lastSeen < 10000))) {
          usersData.push(user);
        }
      });
      
      setUsers(usersData);
      setIsConnecting(false);
    });

    // Listen for messages
    const messagesRef = ref(database, `rooms/${roomId}/messages`);
    const messagesList: ChatMessage[] = [];
    
    const unsubscribeMessages = onChildAdded(messagesRef, (snapshot) => {
      const message = snapshot.val() as ChatMessage;
      if (message && !messagesList.some(m => m.id === message.id)) {
        messagesList.push(message);
        setMessages([...messagesList]);
      }
    });

    // Cleanup on unmount
    return () => {
      clearInterval(presenceInterval);
      unsubscribeUsers();
      unsubscribeMessages();
      if (userPresenceRef.current) {
        remove(userPresenceRef.current);
      }
    };
  }, [roomId, displayName, navigate]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendText = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !roomId) return;

    const newMsg: ChatMessage = {
      id: uuidv4(),
      sender: displayName!,
      senderId: myId.current,
      text: inputText.trim(),
      timestamp: Date.now(),
    };

    const messagesRef = ref(database, `rooms/${roomId}/messages`);
    push(messagesRef, newMsg);
    
    setInputText('');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !roomId) return;

    if (file.size > 5 * 1024 * 1024) {
      toast.error('File size must be less than 5MB');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64Data = event.target?.result as string;
      const newMsg: ChatMessage = {
        id: uuidv4(),
        sender: displayName!,
        senderId: myId.current,
        fileData: base64Data,
        fileType: file.type,
        fileName: file.name,
        timestamp: Date.now(),
      };

      const messagesRef = ref(database, `rooms/${roomId}/messages`);
      push(messagesRef, newMsg);
      
      toast.success('File sent!');
    };
    reader.onerror = () => {
      toast.error('Failed to read file');
    };
    reader.readAsDataURL(file);
    
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const copyLink = () => {
    const link = `${window.location.origin}/?room=${roomId}`;
    navigator.clipboard.writeText(link);
    toast.success('Join link copied to clipboard!');
  };

  const renderMessage = (msg: ChatMessage) => {
    const isMyMessage = msg.senderId === myId.current;

    return (
      <div
        key={msg.id}
        className={cn(
          'flex mb-4 animate-in fade-in slide-in-from-bottom-2',
          isMyMessage ? 'justify-end' : 'justify-start'
        )}
      >
        <div
          className={cn(
            'max-w-md px-4 py-2 rounded-2xl shadow-lg',
            isMyMessage
              ? 'bg-blue-600 text-white rounded-br-sm'
              : 'bg-neutral-800 text-neutral-100 rounded-bl-sm'
          )}
        >
          {!isMyMessage && (
            <div className="text-xs text-neutral-400 mb-1 font-semibold">
              {msg.sender}
            </div>
          )}
          
          {msg.text && <p className="text-sm leading-relaxed break-words">{msg.text}</p>}
          
          {msg.fileData && msg.fileType?.startsWith('image/') && (
            <img
              src={msg.fileData}
              alt={msg.fileName}
              className="max-w-full rounded-lg mt-2"
            />
          )}
          
          {msg.fileData && msg.fileType?.startsWith('video/') && (
            <video
              src={msg.fileData}
              controls
              className="max-w-full rounded-lg mt-2"
            />
          )}
          
          {msg.fileName && (
            <div className="text-xs mt-1 opacity-75">
              {msg.fileName}
            </div>
          )}
          
          <div className={cn(
            "text-xs mt-1",
            isMyMessage ? "text-blue-200" : "text-neutral-500"
          )}>
            {new Date(msg.timestamp).toLocaleTimeString([], {
              hour: '2-digit',
              minute: '2-digit',
            })}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="flex h-screen bg-neutral-950 text-neutral-100 font-sans">
      {/* Sidebar */}
      <div className="w-80 border-r border-neutral-800 bg-neutral-900 flex flex-col hidden md:flex">
        <div className="p-6 border-b border-neutral-800">
          <h2 className="text-xl font-bold tracking-tight mb-1 text-white">ChatKool</h2>
          <div className="text-sm text-neutral-400 flex items-center gap-2">
            <span className={cn(
              "w-2 h-2 rounded-full",
              isConnecting ? "bg-yellow-500 animate-pulse" : "bg-emerald-500 animate-pulse"
            )} />
            {isConnecting ? 'Connecting...' : `Online (${users.length} ${users.length === 1 ? 'user' : 'users'})`}
          </div>
        </div>
        
        <div className="flex-1 p-6 overflow-y-auto">
          <div className="bg-neutral-800/50 rounded-xl p-4 mb-6 border border-neutral-700">
            <p className="text-xs text-neutral-400 uppercase font-semibold mb-2">Room Code</p>
            <div className="text-2xl font-mono text-white tracking-wider mb-4 select-all">{roomId}</div>
            <button
              onClick={copyLink}
              className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg flex items-center justify-center gap-2 text-sm font-medium transition-colors"
            >
              <Share2 size={16} />
              Copy Join Link
            </button>
          </div>

          {/* Users List */}
          <div className="mb-4">
            <p className="text-xs text-neutral-400 uppercase font-semibold mb-3 flex items-center gap-2">
              <Users size={14} />
              Active Users ({users.length})
            </p>
            <div className="space-y-2">
              {users.map((user) => {
                const isMe = user.id === myId.current;
                return (
                  <div 
                    key={user.id} 
                    className={cn(
                      "flex items-center gap-2 p-2 rounded-lg transition-all",
                      isMe ? "bg-blue-600/20 border border-blue-600/30" : "bg-neutral-800/50"
                    )}
                  >
                    <div className={cn(
                      "w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold relative",
                      isMe ? "bg-blue-600" : "bg-neutral-700"
                    )}>
                      {user.name.charAt(0).toUpperCase()}
                      <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-neutral-900" />
                    </div>
                    <span className={cn(
                      "text-sm",
                      isMe ? "text-blue-200 font-medium" : "text-neutral-300"
                    )}>
                      {user.name} {isMe && '(You)'}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="text-sm text-neutral-500 bg-neutral-800/30 p-3 rounded-lg">
            <p className="mb-2 font-medium text-neutral-400">💡 How to use:</p>
            <ul className="space-y-1 text-xs">
              <li>• Share the link with anyone</li>
              <li>• Works on any device</li>
              <li>• Real-time sync across all users</li>
              <li>• Send text, images, and videos</li>
            </ul>
          </div>
        </div>

        <div className="p-4 border-t border-neutral-800">
          <button
            onClick={() => navigate('/')}
            className="w-full py-2 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-lg flex items-center justify-center gap-2 text-sm font-medium transition-colors"
          >
            <LogOut size={16} />
            Leave Room
          </button>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col bg-[#0A0A0A]">
        {/* Mobile Header */}
        <div className="md:hidden p-4 border-b border-neutral-800 bg-neutral-900 flex items-center justify-between">
          <div>
            <h2 className="font-bold text-white">Room: {roomId}</h2>
            <div className="text-xs text-neutral-400 flex items-center gap-1 mt-1">
              <span className={cn(
                "w-1.5 h-1.5 rounded-full",
                isConnecting ? "bg-yellow-500" : "bg-emerald-500"
              )} />
              {users.length} online
            </div>
          </div>
          <button onClick={copyLink} className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            <Share2 size={18} />
          </button>
        </div>

        {/* Messages Container */}
        <div className="flex-1 overflow-y-auto p-6">
          {messages.length === 0 && !isConnecting && (
            <div className="h-full flex flex-col items-center justify-center text-neutral-500">
              <Users size={48} className="mb-4 opacity-50" />
              <p className="text-lg mb-2 font-semibold">No messages yet</p>
              <p className="text-sm text-center max-w-md">
                {users.length === 1 
                  ? "Share the room link with others to start chatting. They'll see all messages in real-time!"
                  : "Start the conversation! Send a message below."}
              </p>
            </div>
          )}

          {isConnecting && (
            <div className="h-full flex flex-col items-center justify-center text-neutral-500">
              <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mb-4" />
              <p className="text-sm">Connecting to room...</p>
            </div>
          )}
          
          {messages.map(renderMessage)}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="border-t border-neutral-800 bg-neutral-900/50 p-4">
          <form onSubmit={handleSendText} className="flex items-end gap-3">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept="image/*,video/*"
              className="hidden"
            />
            
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="p-3 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded-lg transition-colors flex-shrink-0"
              title="Attach image or video"
            >
              <Paperclip size={20} />
            </button>

            <div className="flex-1 bg-neutral-800 rounded-lg border border-neutral-700 focus-within:border-blue-600 transition-colors">
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendText(e);
                  }
                }}
                placeholder="Type a message..."
                className="w-full bg-transparent px-4 py-3 text-sm text-neutral-100 placeholder-neutral-500 outline-none resize-none"
                rows={1}
                style={{
                  maxHeight: '120px',
                  minHeight: '48px',
                }}
              />
            </div>

            <button
              type="submit"
              disabled={!inputText.trim()}
              className="p-3 bg-blue-600 hover:bg-blue-700 disabled:bg-neutral-800 disabled:text-neutral-600 text-white rounded-lg transition-colors flex-shrink-0 disabled:cursor-not-allowed"
            >
              <Send size={20} />
            </button>
          </form>
          
          <p className="text-xs text-neutral-600 mt-2 text-center">
            Press Enter to send • Shift+Enter for new line
          </p>
        </div>
      </div>
    </div>
  );
}
